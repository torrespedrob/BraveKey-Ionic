import { Build } from './build';

describe('Build', () => {
  it('should create an instance', () => {
    expect(new Build()).toBeTruthy();
  });
});
